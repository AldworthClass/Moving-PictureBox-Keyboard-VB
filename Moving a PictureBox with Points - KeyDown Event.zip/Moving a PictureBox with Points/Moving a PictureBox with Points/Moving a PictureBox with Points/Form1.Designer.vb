﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMoveImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.imgCookie = New System.Windows.Forms.PictureBox()
        Me.imgPacMan = New System.Windows.Forms.PictureBox()
        Me.imgRock = New System.Windows.Forms.PictureBox()
        Me.imgRock2 = New System.Windows.Forms.PictureBox()
        Me.imgRock3 = New System.Windows.Forms.PictureBox()
        CType(Me.imgCookie, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgPacMan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.imgRock3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imgCookie
        '
        Me.imgCookie.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.Cookie
        Me.imgCookie.Location = New System.Drawing.Point(149, 80)
        Me.imgCookie.Name = "imgCookie"
        Me.imgCookie.Size = New System.Drawing.Size(34, 34)
        Me.imgCookie.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgCookie.TabIndex = 5
        Me.imgCookie.TabStop = False
        '
        'imgPacMan
        '
        Me.imgPacMan.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.PacRight
        Me.imgPacMan.Location = New System.Drawing.Point(259, 153)
        Me.imgPacMan.Name = "imgPacMan"
        Me.imgPacMan.Size = New System.Drawing.Size(67, 64)
        Me.imgPacMan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgPacMan.TabIndex = 4
        Me.imgPacMan.TabStop = False
        '
        'imgRock
        '
        Me.imgRock.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock.Location = New System.Drawing.Point(292, 30)
        Me.imgRock.Name = "imgRock"
        Me.imgRock.Size = New System.Drawing.Size(91, 73)
        Me.imgRock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock.TabIndex = 6
        Me.imgRock.TabStop = False
        '
        'imgRock2
        '
        Me.imgRock2.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock2.Location = New System.Drawing.Point(119, 212)
        Me.imgRock2.Name = "imgRock2"
        Me.imgRock2.Size = New System.Drawing.Size(91, 73)
        Me.imgRock2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock2.TabIndex = 8
        Me.imgRock2.TabStop = False
        '
        'imgRock3
        '
        Me.imgRock3.Image = Global.Moving_a_PictureBox_with_Points.My.Resources.Resources.rock
        Me.imgRock3.Location = New System.Drawing.Point(383, 212)
        Me.imgRock3.Name = "imgRock3"
        Me.imgRock3.Size = New System.Drawing.Size(91, 73)
        Me.imgRock3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgRock3.TabIndex = 9
        Me.imgRock3.TabStop = False
        '
        'frmMoveImage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(589, 500)
        Me.Controls.Add(Me.imgRock3)
        Me.Controls.Add(Me.imgRock2)
        Me.Controls.Add(Me.imgRock)
        Me.Controls.Add(Me.imgCookie)
        Me.Controls.Add(Me.imgPacMan)
        Me.Name = "frmMoveImage"
        Me.Text = "Move Image"
        CType(Me.imgCookie, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgPacMan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.imgRock3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents imgPacMan As PictureBox
    Friend WithEvents imgCookie As PictureBox
    Friend WithEvents imgRock As PictureBox
    Friend WithEvents imgRock2 As PictureBox
    Friend WithEvents imgRock3 As PictureBox
End Class
